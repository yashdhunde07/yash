import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector
import random
from PIL import Image, ImageTk

class BankManagementSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("Bank Management System")
        self.root.geometry("1280x720")
        
        # Database Connection
        self.conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="bank_db"
        )
        self.cursor = self.conn.cursor()

        # GUI Setup
        self.setup_gui()
        self.create_widgets()

    def setup_gui(self):
        # Background Image
        try:
            self.bg_image = Image.open("freepek.png")
            self.bg_image = self.bg_image.resize((1280, 720), Image.Resampling.LANCZOS)
            self.bg_photo = ImageTk.PhotoImage(self.bg_image)
            self.canvas = tk.Canvas(self.root)
            self.canvas.pack(fill="both", expand=True)
            self.canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")
        except FileNotFoundError:
            self.canvas = tk.Canvas(self.root, bg='#f0f2f5')
            self.canvas.pack(fill="both", expand=True)

        # Main Frame using pack()
        self.main_frame = ttk.Frame(self.canvas)
        self.main_frame.pack(pady=50, expand=True)

        # Styling
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure('TFrame', background='#ffffff')
        self.style.configure('Accent.TButton', 
                           font=('Arial', 12), 
                           foreground='white',
                           background='#2ecc71',
                           padding=10)
        self.style.map('Accent.TButton', background=[('active', '#27ae60')])

    def create_widgets(self):
        # Header Frame
        header_frame = ttk.Frame(self.main_frame)
        header_frame.pack(pady=20)
        
        ttk.Label(header_frame, 
                text="🏦 NextGen Banking System", 
                font=('Arial', 24, 'bold'), 
                foreground='#2c3e50').pack()

        # Buttons Frame
        buttons_frame = ttk.Frame(self.main_frame)
        buttons_frame.pack(pady=20)

        buttons = [
            ('👾Create Account', self.create_account),
            ('🧑‍🦱All Accounts', self.show_accounts),
            ('🔄️Deposit Money', self.deposit_money),
            ('💸Withdraw Money', self.withdraw_money),
            ('⚖️*️Check Balance', self.check_balance),
            ('*️⃣ Modify Account', self.modify_account),
            ('🔑Update Password', self.update_password),
            ('❌Close Account', self.close_account)
        ]

        # Use grid inside buttons_frame
        for i, (text, command) in enumerate(buttons):
            ttk.Button(buttons_frame,
                      text=text,
                      command=command,
                      style='Accent.TButton',
                      width=20).grid(row=i//2, column=i%2, padx=10, pady=10)

    # ----- Core Banking Functions -----
    
    def generate_account_number(self):
        while True:
            acc_no = random.randint(1000000000, 9999999999)
            self.cursor.execute("SELECT accNo FROM accounts WHERE accNo = %s", (acc_no,))
            if not self.cursor.fetchone():
                return acc_no

    def create_account(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Create New Account")
        dialog.geometry("400x300")
        
        fields = [
            ("Name:", 0),
            ("Account Type (C/S):", 1),
            ("Initial Deposit:", 2),
            ("Password:", 3)
        ]
        
        entries = []
        for label, row in fields:
            ttk.Label(dialog, text=label).grid(row=row, column=0, padx=10, pady=5)
            entry = ttk.Entry(dialog, show='*' if "Password" in label else '')
            entry.grid(row=row, column=1, padx=10, pady=5)
            entries.append(entry)

        def submit():
            try:
                acc_no = self.generate_account_number()
                name = entries[0].get()
                acc_type = entries[1].get().upper()
                deposit = int(entries[2].get())
                password = entries[3].get()

                if acc_type not in ['C', 'S']:
                    messagebox.showerror("Error", "Account type must be C (Current) or S (Saving)!")
                    return
                
                min_deposit = 1000 if acc_type == 'C' else 500
                if deposit < min_deposit:
                    messagebox.showerror("Error", f"Minimum deposit: ₹{min_deposit}")
                    return

                self.cursor.execute("INSERT INTO accounts VALUES (%s, %s, %s, %s, %s)", 
                                  (acc_no, name, acc_type, deposit, password))
                self.conn.commit()
                messagebox.showinfo("Success", f"Account Created!\nAccount Number: {acc_no}")
                dialog.destroy()
            except ValueError:
                messagebox.showerror("Error", "Invalid amount entered!")
            except Exception as e:
                messagebox.showerror("Error", str(e))

        ttk.Button(dialog, text="Submit", command=submit).grid(row=4, columnspan=2, pady=10)

    def show_accounts(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("All Accounts")
        dialog.geometry("800x400")
        
        tree = ttk.Treeview(dialog, columns=('AccNo', 'Name', 'Type', 'Balance'), show='headings')
        tree.heading('AccNo', text="Account Number")
        tree.heading('Name', text="Account Holder")
        tree.heading('Type', text="Type")
        tree.heading('Balance', text="Balance")
        tree.pack(fill='both', expand=True, padx=10, pady=10)
        
        self.cursor.execute("SELECT accNo, name, type, deposit FROM accounts")
        for row in self.cursor.fetchall():
            tree.insert('', 'end', values=row)

    def deposit_money(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Deposit Money")
        dialog.geometry("300x200")
        
        ttk.Label(dialog, text="Account Number:").grid(row=0, column=0, padx=10, pady=5)
        acc_entry = ttk.Entry(dialog)
        acc_entry.grid(row=0, column=1, padx=10, pady=5)
        
        ttk.Label(dialog, text="Password:").grid(row=1, column=0, padx=10, pady=5)
        pwd_entry = ttk.Entry(dialog, show='*')
        pwd_entry.grid(row=1, column=1, padx=10, pady=5)
        
        ttk.Label(dialog, text="Amount:").grid(row=2, column=0, padx=10, pady=5)
        amt_entry = ttk.Entry(dialog)
        amt_entry.grid(row=2, column=1, padx=10, pady=5)

        def process():
            try:
                acc_no = int(acc_entry.get())
                amount = int(amt_entry.get())
                password = pwd_entry.get()
                
                self.cursor.execute("SELECT deposit FROM accounts WHERE accNo=%s AND password=%s", 
                                  (acc_no, password))
                result = self.cursor.fetchone()
                
                if result:
                    new_balance = result[0] + amount
                    self.cursor.execute("UPDATE accounts SET deposit=%s WHERE accNo=%s", 
                                     (new_balance, acc_no))
                    self.conn.commit()
                    messagebox.showinfo("Success", 
                                      f"Deposited: ₹{amount}\nNew Balance: ₹{new_balance}")
                    dialog.destroy()
                else:
                    messagebox.showerror("Error", "Invalid Credentials!")
            except:
                messagebox.showerror("Error", "Invalid Input!")

        ttk.Button(dialog, text="Deposit", command=process).grid(row=3, columnspan=2, pady=10)

    def withdraw_money(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Withdraw Money")
        dialog.geometry("300x200")
        
        ttk.Label(dialog, text="Account Number:").grid(row=0, column=0, padx=10, pady=5)
        acc_entry = ttk.Entry(dialog)
        acc_entry.grid(row=0, column=1, padx=10, pady=5)
        
        ttk.Label(dialog, text="Password:").grid(row=1, column=0, padx=10, pady=5)
        pwd_entry = ttk.Entry(dialog, show='*')
        pwd_entry.grid(row=1, column=1, padx=10, pady=5)
        
        ttk.Label(dialog, text="Amount:").grid(row=2, column=0, padx=10, pady=5)
        amt_entry = ttk.Entry(dialog)
        amt_entry.grid(row=2, column=1, padx=10, pady=5)

        def process():
            try:
                acc_no = int(acc_entry.get())
                amount = int(amt_entry.get())
                password = pwd_entry.get()
                
                self.cursor.execute("SELECT deposit FROM accounts WHERE accNo=%s AND password=%s", 
                                  (acc_no, password))
                result = self.cursor.fetchone()
                
                if result:
                    if result[0] >= amount:
                        new_balance = result[0] - amount
                        self.cursor.execute("UPDATE accounts SET deposit=%s WHERE accNo=%s", 
                                         (new_balance, acc_no))
                        self.conn.commit()
                        messagebox.showinfo("Success", 
                                          f"Withdrawn: ₹{amount}\nRemaining Balance: ₹{new_balance}")
                        dialog.destroy()
                    else:
                        messagebox.showerror("Error", "Insufficient Balance!")
                else:
                    messagebox.showerror("Error", "Invalid Credentials!")
            except:
                messagebox.showerror("Error", "Invalid Input!")

        ttk.Button(dialog, text="Withdraw", command=process).grid(row=3, columnspan=2, pady=10)

    def check_balance(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Check Balance")
        dialog.geometry("300x150")
        
        ttk.Label(dialog, text="Account Number:").grid(row=0, column=0, padx=10, pady=5)
        acc_entry = ttk.Entry(dialog)
        acc_entry.grid(row=0, column=1, padx=10, pady=5)
        
        ttk.Label(dialog, text="Password:").grid(row=1, column=0, padx=10, pady=5)
        pwd_entry = ttk.Entry(dialog, show='*')
        pwd_entry.grid(row=1, column=1, padx=10, pady=5)

        def check():
            try:
                acc_no = int(acc_entry.get())
                password = pwd_entry.get()
                
                self.cursor.execute("SELECT deposit FROM accounts WHERE accNo=%s AND password=%s", 
                                  (acc_no, password))
                result = self.cursor.fetchone()
                
                if result:
                    messagebox.showinfo("Balance", f"Current Balance: ₹{result[0]}")
                    dialog.destroy()
                else:
                    messagebox.showerror("Error", "Invalid Credentials!")
            except:
                messagebox.showerror("Error", "Invalid Input!")

        ttk.Button(dialog, text="Check Balance", command=check).grid(row=2, columnspan=2, pady=10)

    def modify_account(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Modify Account")
        dialog.geometry("300x200")
        
        ttk.Label(dialog, text="Account Number:").grid(row=0, column=0, padx=10, pady=5)
        acc_entry = ttk.Entry(dialog)
        acc_entry.grid(row=0, column=1, padx=10, pady=5)
        
        ttk.Label(dialog, text="Password:").grid(row=1, column=0, padx=10, pady=5)
        pwd_entry = ttk.Entry(dialog, show='*')
        pwd_entry.grid(row=1, column=1, padx=10, pady=5)
        
        ttk.Label(dialog, text="New Name:").grid(row=2, column=0, padx=10, pady=5)
        name_entry = ttk.Entry(dialog)
        name_entry.grid(row=2, column=1, padx=10, pady=5)

        def update():
            try:
                acc_no = int(acc_entry.get())
                password = pwd_entry.get()
                new_name = name_entry.get()
                
                self.cursor.execute("SELECT * FROM accounts WHERE accNo=%s AND password=%s", 
                                  (acc_no, password))
                if self.cursor.fetchone():
                    self.cursor.execute("UPDATE accounts SET name=%s WHERE accNo=%s", 
                                     (new_name, acc_no))
                    self.conn.commit()
                    messagebox.showinfo("Success", "Account Updated Successfully!")
                    dialog.destroy()
                else:
                    messagebox.showerror("Error", "Invalid Credentials!")
            except:
                messagebox.showerror("Error", "Invalid Input!")

        ttk.Button(dialog, text="Update", command=update).grid(row=3, columnspan=2, pady=10)

    def update_password(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Update Password")
        dialog.geometry("300x200")
        
        ttk.Label(dialog, text="Account Number:").grid(row=0, column=0, padx=10, pady=5)
        acc_entry = ttk.Entry(dialog)
        acc_entry.grid(row=0, column=1, padx=10, pady=5)
        
        ttk.Label(dialog, text="Old Password:").grid(row=1, column=0, padx=10, pady=5)
        old_pwd_entry = ttk.Entry(dialog, show='*')
        old_pwd_entry.grid(row=1, column=1, padx=10, pady=5)
        
        ttk.Label(dialog, text="New Password:").grid(row=2, column=0, padx=10, pady=5)
        new_pwd_entry = ttk.Entry(dialog, show='*')
        new_pwd_entry.grid(row=2, column=1, padx=10, pady=5)

        def update():
            try:
                acc_no = int(acc_entry.get())
                old_pwd = old_pwd_entry.get()
                new_pwd = new_pwd_entry.get()
                
                self.cursor.execute("SELECT * FROM accounts WHERE accNo=%s AND password=%s", 
                                  (acc_no, old_pwd))
                if self.cursor.fetchone():
                    self.cursor.execute("UPDATE accounts SET password=%s WHERE accNo=%s", 
                                     (new_pwd, acc_no))
                    self.conn.commit()
                    messagebox.showinfo("Success", "Password Updated Successfully!")
                    dialog.destroy()
                else:
                    messagebox.showerror("Error", "Invalid Credentials!")
            except:
                messagebox.showerror("Error", "Invalid Input!")

        ttk.Button(dialog, text="Update Password", command=update).grid(row=3, columnspan=2, pady=10)

    def close_account(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Close Account")
        dialog.geometry("300x150")
        
        ttk.Label(dialog, text="Account Number:").grid(row=0, column=0, padx=10, pady=5)
        acc_entry = ttk.Entry(dialog)
        acc_entry.grid(row=0, column=1, padx=10, pady=5)
        
        ttk.Label(dialog, text="Password:").grid(row=1, column=0, padx=10, pady=5)
        pwd_entry = ttk.Entry(dialog, show='*')
        pwd_entry.grid(row=1, column=1, padx=10, pady=5)

        def delete():
            try:
                acc_no = int(acc_entry.get())
                password = pwd_entry.get()
                
                self.cursor.execute("SELECT * FROM accounts WHERE accNo=%s AND password=%s", 
                                  (acc_no, password))
                if self.cursor.fetchone():
                    self.cursor.execute("DELETE FROM accounts WHERE accNo=%s", (acc_no,))
                    self.conn.commit()
                    messagebox.showinfo("Success", "Account Closed Successfully!")
                    dialog.destroy()
                else:
                    messagebox.showerror("Error", "Invalid Credentials!")
            except:
                messagebox.showerror("Error", "Invalid Input!")

        ttk.Button(dialog, text="Close Account", command=delete).grid(row=2, columnspan=2, pady=10)

    def __del__(self):
        self.cursor.close()
        self.conn.close()

if __name__ == "__main__":
    root = tk.Tk()
    app = BankManagementSystem(root)
    root.mainloop()