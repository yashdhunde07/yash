import mysql.connector
import random

# Connect to MySQL
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="yash@123",  # Replace with your MySQL root password
    database="bank_db"
)
cursor = conn.cursor()

# Create table if not exists
cursor.execute("""
    CREATE TABLE IF NOT EXISTS accounts (
        accNo BIGINT PRIMARY KEY,
        name VARCHAR(100),
        type CHAR(1),
        deposit INT,
        password VARCHAR(255)
    )
""")

# Function to generate a unique 10-digit account number
def generate_account_number():
    while True:
        accNo = random.randint(1000000000, 9999999999)  # Generate 10-digit number
        cursor.execute("SELECT accNo FROM accounts WHERE accNo = %s", (accNo,))
        if not cursor.fetchone():  # If not found, return the unique number
            return accNo

# Function to create a new account
def create_account():
    accNo = generate_account_number()
    name = input("Enter the account holder name: ")
    acc_type = input("Enter the type of account [C/S]: ").upper()
    deposit = int(input("Enter initial deposit (>=500 for Saving, >=1000 for Current): "))
    password = input("Set a password: ")

    cursor.execute("INSERT INTO accounts VALUES (%s, %s, %s, %s, %s)", 
                   (accNo, name, acc_type, deposit, password))
    conn.commit()

    print(f"\n✅ Account Created Successfully! Your Account Number: {accNo}")

# Function to display all accounts
def display_all():
    cursor.execute("SELECT accNo, name, type, deposit FROM accounts")
    records = cursor.fetchall()
    if records:
        print("\nAccount Details:")
        for record in records:
            print(record)
    else:
        print("No accounts found.")

# Function to deposit money
def deposit_amount():
    accNo = int(input("Enter your account number: "))
    password = input("Enter your password: ")
    amount = int(input("Enter amount to deposit: "))
    
    cursor.execute("SELECT deposit FROM accounts WHERE accNo = %s AND password = %s", (accNo, password))
    record = cursor.fetchone()
    if record:
        new_balance = record[0] + amount
        cursor.execute("UPDATE accounts SET deposit = %s WHERE accNo = %s", (new_balance, accNo))
        conn.commit()
        print("✅ Deposit successful!")
    else:
        print("❌ Invalid account number or password!")

# Function to withdraw money
def withdraw_amount():
    accNo = int(input("Enter your account number: "))
    password = input("Enter your password: ")
    amount = int(input("Enter amount to withdraw: "))
    
    cursor.execute("SELECT deposit FROM accounts WHERE accNo = %s AND password = %s", (accNo, password))
    record = cursor.fetchone()
    if record and record[0] >= amount:
        new_balance = record[0] - amount
        cursor.execute("UPDATE accounts SET deposit = %s WHERE accNo = %s", (new_balance, accNo))
        conn.commit()
        print("✅ Withdrawal successful!")
    else:
        print("❌ Insufficient balance or invalid credentials!")

# Function to check account balance
def check_balance():
    accNo = int(input("Enter your account number: "))
    password = input("Enter your password: ")

    cursor.execute("SELECT deposit FROM accounts WHERE accNo = %s AND password = %s", (accNo, password))
    record = cursor.fetchone()
    
    if record:
        print(f"💰 Your current balance is: ₹{record[0]}")
    else:
        print("❌ Invalid account number or password!")

# Function to modify an existing account
def modify_account():
    accNo = int(input("Enter the account number to modify: "))
    password = input("Enter your password: ")
    
    cursor.execute("SELECT * FROM accounts WHERE accNo = %s AND password = %s", (accNo, password))
    record = cursor.fetchone()
    
    if record:
        print("\n✅ Account Found!")
        new_name = input("Enter new account holder name: ")
        new_type = input("Enter new account type [C/S]: ").upper()

        cursor.execute("UPDATE accounts SET name = %s, type = %s WHERE accNo = %s", 
                       (new_name, new_type, accNo))
        conn.commit()
        print("✅ Account updated successfully!")
    else:
        print("❌ Invalid account number or password!")

# Function to close an account
def close_account():
    accNo = int(input("Enter the account number to close: "))
    password = input("Enter your password: ")
    
    cursor.execute("SELECT * FROM accounts WHERE accNo = %s AND password = %s", (accNo, password))
    record = cursor.fetchone()
    
    if record:
        confirm = input("Are you sure you want to close this account? (yes/no): ").lower()
        if confirm == 'yes':
            cursor.execute("DELETE FROM accounts WHERE accNo = %s", (accNo,))
            conn.commit()
            print("✅ Account closed successfully!")
        else:
            print("❌ Account closure cancelled.")
    else:
        print("❌ Invalid account number or password!")

# Main menu
while True:
    print("\n===== BANK MANAGEMENT SYSTEM =====")
    print("1. Create New Account")
    print("2. Display All Accounts")
    print("3. Deposit Money")
    print("4. Withdraw Money")
    print("5. Check Balance")
    print("6. Modify Existing Account")
    print("7. Close Account")
    print("8. Exit")
    
    choice = input("Select an option: ")

    if choice == '1':
        create_account()
    elif choice == '2':
        display_all()
    elif choice == '3':
        deposit_amount()
    elif choice == '4':
        withdraw_amount()
    elif choice == '5':
        check_balance()
    elif choice == '6':
        modify_account()
    elif choice == '7':
        close_account()
    elif choice == '8':
        print("Exiting... Thank you!")
        break
    else:
        print("Invalid choice, try again.")

# Close the connection
cursor.close()
conn.close()
