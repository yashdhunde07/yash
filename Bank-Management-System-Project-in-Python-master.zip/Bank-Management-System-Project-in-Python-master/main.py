import mysql.connector
import random

# ✅ Connect to MySQL Database
db = mysql.connector.connect(
    host="localhost",
    user="root",      # Change if your MySQL user is different
    password="",      # Enter your MySQL password here
    database="bank_db"
)
cursor = db.cursor()

class Account:
    def __init__(self):
        self.accNo = None
        self.name = ""
        self.type = ""
        self.deposit = 0.0
        self.password = ""

    def createAccount(self):
        self.accNo = random.randint(1000000000, 9999999999)  # Generate 10-digit unique accNo
        self.name = input("Enter your name: ")
        self.type = input("Enter account type (S for Savings, C for Current): ").upper()
        self.deposit = float(input("Enter initial deposit: "))
        self.password = input("Set a password: ")

        # ✅ Store account in MySQL
        cursor.execute(
            "INSERT INTO accounts (accNo, name, type, deposit, password) VALUES (%s, %s, %s, %s, %s)",
            (self.accNo, self.name, self.type, self.deposit, self.password)
        )
        db.commit()
        print(f"\n✅ Account Created! Your Account No: {self.accNo}")

    def displayAccount(self, accNo):
        cursor.execute("SELECT * FROM accounts WHERE accNo = %s", (accNo,))
        account = cursor.fetchone()
        if account:
            print(f"\n📌 Account No: {account[0]}")
            print(f"👤 Holder Name: {account[1]}")
            print(f"🏦 Account Type: {account[2]}")
            print(f"💰 Balance: {account[3]}")
        else:
            print("❌ Account not found.")

    def depositAmount(self, accNo, amount):
        cursor.execute("UPDATE accounts SET deposit = deposit + %s WHERE accNo = %s", (amount, accNo))
        db.commit()
        print("✅ Deposit Successful!")

    def withdrawAmount(self, accNo, amount):
        cursor.execute("SELECT deposit FROM accounts WHERE accNo = %s", (accNo,))
        balance = cursor.fetchone()
        if balance and balance[0] >= amount:
            cursor.execute("UPDATE accounts SET deposit = deposit - %s WHERE accNo = %s", (amount, accNo))
            db.commit()
            print("✅ Withdrawal Successful!")
        else:
            print("❌ Insufficient Balance!")

# ✅ Run the program in CMD
if __name__ == "__main__":
    account = Account()
    while True:
        print("\n1️⃣ Create Account\n2️⃣ Display Account\n3️⃣ Deposit\n4️⃣ Withdraw\n5️⃣ Exit")
        choice = input("Enter choice: ")

        if choice == "1":
            account.createAccount()
        elif choice == "2":
            accNo = int(input("Enter Account No: "))
            account.displayAccount(accNo)
        elif choice == "3":
            accNo = int(input("Enter Account No: "))
            amount = float(input("Enter amount to deposit: "))
            account.depositAmount(accNo, amount)
        elif choice == "4":
            accNo = int(input("Enter Account No: "))
            amount = float(input("Enter amount to withdraw: "))
            account.withdrawAmount(accNo, amount)
        elif choice == "5":
            print("🚀 Exiting Bank System...")
            break
        else:
            print("❌ Invalid Choice!")
