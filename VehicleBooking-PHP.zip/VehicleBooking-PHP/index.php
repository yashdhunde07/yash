<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("vendor/inc/head.php");?>
    <style>
        /* Custom CSS */
        body {
            background-color: #f8f9fa;
        }

        .carousel-item {
            height: 400px; /* Adjust as needed */
            background-size: cover;
            background-position: center;
        }

        .card {
            border: none;
        }

        .card-header {
            background-color: #007bff;
            color: #fff;
        }

        .card-body {
            background-color: #fff;
        }

        .card-text {
            color: #333;
        }

        .portfolio-item img {
            width: 100%;
            height: auto;
        }

        .center {
            text-align: center;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .carousel-item {
                height: 250px; /* Adjust as needed */
            }
        }
    </style>
</head>
<body>

<?php include("vendor/inc/nav.php");?>

<header>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner" role="listbox">
            <!-- Slide One - Set the background image for this slide in the line below -->
            <div class="carousel-item active" style="background-image: url('vendor/img/ambulance.png')">
            </div>
            <!-- Slide Two - Set the background image for this slide in the line below -->
            <div class="carousel-item" style="background-image: url('vendor/img/r.jpg')">
            </div>
            <!-- Slide Three - Set the background image for this slide in the line below -->
            <div class="carousel-item" style="background-image: url('vendor/img/123.jpg')">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</header>

<div class="container my-4">
    <h1 class="text-center">Welcome to Ambulance Booking System</h1>

    <div class="row mt-4">
        <div class="col-lg-6 mb-4">
            <div class="card h-100">
                <h4 class="card-header">WELCOME</h4>
                <div class="card-body">
                    <p class="card-text">We create accountability in the transport sector, enhance mobility and ease of accessing various transport modes</p>
                </div>
            </div>
        </div>
        <div class="col-lg-6 mb-4">
            <div class="card h-100">
                <h4 class="card-header">Core Values</h4>
                <div class="card-body">
                    <p class="card-text">Excellence, Trust and Openness, Integrity, Take Responsibility, Customer Orientation</p>
                </div>
            </div>
        </div>
    </div>

    <hr>

 

    <div class="row">
        <div class="col-lg-4 col-sm-6 portfolio-item">
            <div class="card h-100">
                <a href="#"><img class="card-img-top" src="vendor/img/ambulance.png" alt=""></a>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 portfolio-item">
            <div class="card h-100">
                <a href="#"><img class="card-img-top" src="vendor/img/r.jpg" alt=""></a>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 portfolio-item">
            <div class="card h-100">
                <a href="#"><img class="card-img-top" src="vendor/img/e.jpg" alt=""></a>
            </div>
        </div>
    </div>

    <hr>

    

    

<?php include("vendor/inc/footer.php");?>

<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>
